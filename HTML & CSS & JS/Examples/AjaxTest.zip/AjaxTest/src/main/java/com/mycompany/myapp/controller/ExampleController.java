package com.mycompany.myapp.controller;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mycompany.myapp.service.ExampleService;
import com.mycompany.myapp.vo.BoardVO;
import com.mycompany.myapp.vo.ReplyVO;

@Controller
@RequestMapping(value = "/example")
public class ExampleController {
	
	private static final Logger logger = LoggerFactory.getLogger(ExampleController.class);
	
	@Autowired
	private ExampleService service;
	
	@RequestMapping(value = "/boardList", method = RequestMethod.GET)
	public String boardList(Model model) {
		logger.info("boardList 메서드 실행.");
		
		ArrayList<BoardVO> list = service.getBoardList();
		model.addAttribute("list", list);
		
		return "example/boardList";
	}
	
	@RequestMapping(value = "/readBoard", method = RequestMethod.GET)
	public String readBoard(Model model, int boardNum) {
		logger.info("readBoard 메서드 실행.");
		
		BoardVO board = service.getBoard(boardNum);
		model.addAttribute("board", board);
		
		return "example/readBoard";
	}
	
	@ResponseBody
	@RequestMapping(value = "/readReply", method = RequestMethod.POST)
	public ArrayList<ReplyVO> readReply(int boardNum) {
		logger.info("readReply 메서드 실행.");
		System.out.println("C1");
		ArrayList<ReplyVO> list = service.getReplyList(boardNum);
		System.out.println("C2");
		return list;
	}
	
	@ResponseBody
	@RequestMapping(value = "/writeReply", method = RequestMethod.POST)
	public void writeReply(ReplyVO reply) {
		logger.info("writeReply 메서드 실행.");
		
		service.writeReply(reply);
	}
	
}
