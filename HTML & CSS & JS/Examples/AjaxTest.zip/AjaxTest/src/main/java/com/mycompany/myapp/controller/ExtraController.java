package com.mycompany.myapp.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.mycompany.myapp.vo.UserVO;

@Controller
@RequestMapping(value = "/extra")
public class ExtraController {

	private static final Logger logger = LoggerFactory.getLogger(ExtraController.class);

	@RequestMapping(value = "/extra1", method = RequestMethod.GET)
	public String extra1() {
		return "ajax/extra1";
	}

	@ResponseBody
	@RequestMapping(value = "/sendArray", method = RequestMethod.POST)
	public void sendArray(String[] arr) {
		logger.info("sendArray 메서드 실행.");
		if (arr != null) {
			for (String s : arr)
				logger.info("페이지로부터 전달받은 데이터 {}", s);
		} else
			logger.info("페이지로부터 전달받은 데이터 {}", arr);
	}
	
	@ResponseBody
	@RequestMapping(value = "/sendVO", method = RequestMethod.POST)
	public void sendVO(UserVO user) {
		logger.info("sendVO 메서드 실행.");
		logger.info("페이지로부터 전달받은 데이터 {}", user);
	}
	
	@ResponseBody
	@RequestMapping(value = "/sendList", method = RequestMethod.POST)
	public void sendList(@RequestBody ArrayList<String> arr) {
		logger.info("sendList 메서드 실행.");
		logger.info("페이지로부터 전달받은 데이터 {}", arr);
	}
	
	@ResponseBody
	@RequestMapping(value = "/sendMap", method = RequestMethod.POST)
	public void sendMap(@RequestBody HashMap<String, Object> map) {
		logger.info("sendMap 메서드 실행.");
		logger.info("페이지로부터 전달받은 데이터 {}", map);
	}
	
	@ResponseBody
	@RequestMapping(value = "/sendListMap", method = RequestMethod.POST)
	public void sendListMap(@RequestBody ArrayList<HashMap<String, Object>> listMap) {
		logger.info("sendListMap 메서드 실행.");
		logger.info("페이지로부터 전달받은 데이터 {}", listMap);
	}
	
	@ResponseBody
	@RequestMapping(value = "/sendMapList", method = RequestMethod.POST)
	public void sendMapList(@RequestBody HashMap<String, ArrayList<String>> mapList) {
		logger.info("sendMapList 메서드 실행.");
		logger.info("페이지로부터 전달받은 데이터 {}", mapList);
	}
	
	@ResponseBody
	@RequestMapping(value = "/receiveArray", method = RequestMethod.POST)
	public String[] receiveArray() {
		logger.info("receiveArray 메서드 실행.");
		
		String[] arr = new String[2];
		arr[0] = "반갑구나";
		arr[1] = "세상아";
		
		return arr;
	}
	
	@ResponseBody
	@RequestMapping(value = "/receiveVO", method = RequestMethod.POST)
	public UserVO receiveVO() {
		logger.info("receiveVO 메서드 실행.");
		
		return new UserVO("반갑구나", "세상아");
	}
	
	@ResponseBody
	@RequestMapping(value = "/receiveList", method = RequestMethod.POST)
	public ArrayList<String> receiveList() {
		logger.info("receiveList 메서드 실행.");
		
		ArrayList<String> list = new ArrayList<String>();
		list.add("반갑구나");
		list.add("세상아");
		
		return list;
	}
	
	@ResponseBody
	@RequestMapping(value = "/receiveMap", method = RequestMethod.POST)
	public HashMap<String, Object> receiveMap() {
		logger.info("receiveMap 메서드 실행.");
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("id", "반갑구나");
		map.put("pw", "세상아");
		
		return map;
	}
	
	@RequestMapping(value = "/extra2", method = RequestMethod.GET)
	public String extra2() {
		return "ajax/extra2";
	}
	
//	@ResponseBody
//	@RequestMapping(value = "/sendFile", method = RequestMethod.POST)
//	public void sendFile(MultipartHttpServletRequest request) {
//		logger.info("sendFile 메서드 실행.");
//		
//		List<MultipartFile> list = request.getFiles("mfile");
//		logger.info("list: {}", list);
//	}
	
	@ResponseBody
	@RequestMapping(value = "/sendFile", method = RequestMethod.POST)
	public void sendFile(@RequestParam("mfile") MultipartFile[] mfile) {
		logger.info("sendFile 메서드 실행.");
		
		if (mfile != null) {
			for (MultipartFile f : mfile) {
				File temp = new File("C:\\Users\\JUNE\\Desktop\\Saved Files\\" + f.getOriginalFilename());
				try {
					f.transferTo(temp);
				} catch (IllegalStateException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} else
			System.out.println(mfile);
	}

}
