package com.mycompany.myapp.vo;

public class BoardVO {
	
	private int boardNum; // 글 번호
	private String title; // 글 제목
	private String writer; // 글쓴이
	private String content; // 글 본문
	private String indate; // 작성일
	private int replyCnt; // 댓글 수
	
	public BoardVO() {
		// TODO Auto-generated constructor stub
	}

	public BoardVO(int boardNum, String title, String writer, String content, String indate, int replyCnt) {
		super();
		this.boardNum = boardNum;
		this.title = title;
		this.writer = writer;
		this.content = content;
		this.indate = indate;
		this.replyCnt = replyCnt;
	}

	public int getBoardNum() {
		return boardNum;
	}

	public void setBoardNum(int boardNum) {
		this.boardNum = boardNum;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getIndate() {
		return indate;
	}

	public void setIndate(String indate) {
		this.indate = indate;
	}

	public int getReplyCnt() {
		return replyCnt;
	}

	public void setReplyCnt(int replyCnt) {
		this.replyCnt = replyCnt;
	}

	@Override
	public String toString() {
		return "BoardVO [boardNum=" + boardNum + ", title=" + title + ", writer=" + writer + ", content=" + content
				+ ", indate=" + indate + ", replyCnt=" + replyCnt + "]";
	}

}
