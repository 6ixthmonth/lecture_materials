package com.mycompany.myapp.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycompany.myapp.dao.ExampleDAO;
import com.mycompany.myapp.vo.BoardVO;
import com.mycompany.myapp.vo.ReplyVO;

@Service
public class ExampleService {

	@Autowired
	private ExampleDAO dao;

	public ArrayList<BoardVO> getBoardList() {
		return dao.getBoardList();
	}

	public BoardVO getBoard(int boardNum) {
		return dao.getBoard(boardNum);
	}

	public ArrayList<ReplyVO> getReplyList(int boardNum) {
		return dao.getReplyList(boardNum);
	}

	public void writeReply(ReplyVO reply) {
		int result = dao.writeReply(reply);
		System.out.println(result > 0 ? "입력 성공" : "입력 실패");
	}

}
