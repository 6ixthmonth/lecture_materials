package com.mycompany.myapp.dao;

import java.util.ArrayList;

import com.mycompany.myapp.vo.BoardVO;
import com.mycompany.myapp.vo.ReplyVO;

public interface ExampleMapper {

	public ArrayList<BoardVO> getBoardList();

	public BoardVO getBoard(int boardNum);

	public ArrayList<ReplyVO> getReplyList(int boardNum);

	public int writeReply(ReplyVO reply);

}
