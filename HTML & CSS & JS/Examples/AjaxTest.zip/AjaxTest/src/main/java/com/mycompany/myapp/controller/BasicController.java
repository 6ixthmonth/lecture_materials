package com.mycompany.myapp.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/basic")
public class BasicController {

	private static final Logger logger = LoggerFactory.getLogger(BasicController.class);
	
	@RequestMapping(value = "/basic1", method = RequestMethod.GET)
	public String basic1() {
		logger.info("AJAX 기초1 페이지로 이동.");
		
		return "ajax/basic1";
	}
	
	@ResponseBody
	@RequestMapping(value = "/firstConn", method = RequestMethod.GET)
	public void firstConn() {
		logger.info("firstConn 메서드 실행.");
	}
	
	@ResponseBody
	@RequestMapping(value = "/sendStr", method = RequestMethod.GET)
	public void sendStr(String str) {
		logger.info("sendStr 메서드 실행.");
		logger.info("페이지에서 전달받은 데이터: {}", str);
	}
	
	@ResponseBody
	@RequestMapping(value = "/receiveStr", method = RequestMethod.GET)
	public String receiveStr() {
		logger.info("receiveStr 메서드 실행.");
		
		String str = "test";
		logger.info("페이지로 전달할 데이터: {}", str);
		
		return str;
	}
	
	@ResponseBody
	@RequestMapping(value = "/sendReceiveStr", method = RequestMethod.POST, produces = "application/text;charset=utf-8;")
	public String sendReceiveStr(String str) {
		logger.info("sendReceiveStr 메서드 실행.");
		
		logger.info("페이지에서 전달받은 데이터: {}", str);
		
		String data = "테스트";
		logger.info("페이지로 전달할 데이터: {}", data);
		
		return data;
	}
	
	@RequestMapping(value = "/basic2", method = RequestMethod.GET)
	public String basic2() {
		return "ajax/basic2";
	}
}
