package com.mycompany.myapp.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mycompany.myapp.vo.UserVO;

@Controller
@RequestMapping(value = "/ajax")
public class AjaxController {

	private static final Logger logger = LoggerFactory.getLogger(AjaxController.class);
	
	@RequestMapping(value = "/intermediate")
	public String intermediate() {
		logger.info("AJAX 중급 페이지로 이동.");
		
		return "ajax/intermediate";
	}
	
	@ResponseBody
	@RequestMapping(value = "/intermediateFirst", method = RequestMethod.POST)
	public void intermediateFirst(String id, String pw) {
		logger.info("intermediateFirst 메서드 실행.");
		logger.info("페이지에서 전달받은 데이터: {}", id);
		logger.info("페이지에서 전달받은 데이터: {}", pw);
	}
	
	@ResponseBody
	@RequestMapping(value = "/intermediateSecond", method = RequestMethod.POST)
	public void intermediateSecond(String[] arr) {
		logger.info("intermediateSecond 메서드 실행.");
		for (String s : arr)
			logger.info("페이지에서 전달받은 데이터: {}", s);
	}
	
	@ResponseBody
	@RequestMapping(value = "/intermediateThird", method = RequestMethod.POST)
	public void intermediateThird(UserVO user) {
		logger.info("intermediateThird 메서드 실행.");
		logger.info("페이지에서 전달받은 데이터: {}", user);
	}
	
	@ResponseBody
	@RequestMapping(value = "/intermediateFourth", method = RequestMethod.POST)
	public String[] intermediateFourth() {
		logger.info("intermediateFourth 메서드 실행.");
		
		String[] arr = new String[2];
		arr[0] = "asdf";
		arr[1] = "1234";
		logger.info("페이지로 전달할 데이터: {}", arr);
		
		return arr;
	}
	
//	@ResponseBody
//	@RequestMapping(value = "/intermediateFourth", method = RequestMethod.POST)
//	public ArrayList<String> intermediateFourth() {
//		logger.info("intermediateFourth 메서드 실행.");
//		
//		ArrayList<String> list = new ArrayList<String>();
//		list.add("asdf");
//		list.add("1234");
//		logger.info("페이지로 전달할 데이터: {}", list);
//		
//		return list;
//	}
	
//	@ResponseBody
//	@RequestMapping(value = "/intermediateFourth", method = RequestMethod.POST)
//	public HashMap<String, Object> intermediateFourth() {
//		logger.info("intermediateFourth 메서드 실행.");
//		
//		HashMap<String, Object> map = new HashMap<String, Object>();
//		map.put("id", "asdf");
//		map.put("pw", "1234");
//		logger.info("페이지로 전달할 데이터: {}", map);
//		
//		return map;
//	}
	
//	@ResponseBody
//	@RequestMapping(value = "/intermediateFourth", method = RequestMethod.POST)
//	public ArrayList<HashMap<String, Object>> intermediateFourth() {
//		logger.info("intermediateFourth 메서드 실행.");
//		
//		ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
//		HashMap<String, Object> map1 = new HashMap<String, Object>();
//		map1.put("id", "asdf");
//		map1.put("pw", "1234");
//		HashMap<String, Object> map2 = new HashMap<String, Object>();
//		map2.put("id", "qwer");
//		map2.put("pw", "5678");
//		list.add(map1);
//		list.add(map2);
//		logger.info("페이지로 전달할 데이터: {}", list);
//		
//		return list;
//	}
	
	@ResponseBody
	@RequestMapping(value = "/intermediateFifth", method = RequestMethod.POST)
	public UserVO intermediateFifth() {
		logger.info("intermediateFifth 메서드 실행.");
		
		UserVO vo = new UserVO("asdf", "1234");
		logger.info("페이지로 전달할 데이터: {}", vo);
		
		return vo;
	}

	@RequestMapping(value = "/advance")
	public String advance() {
		logger.info("AJAX 심화 페이지로 이동.");
		
		return "ajax/advance";
	}
	
	@ResponseBody
	@RequestMapping(value = "/advanceFirst", method = RequestMethod.POST)
	public void advanceFirst(@RequestBody UserVO user) {
		logger.info("advanceFirst 메서드 실행.");
		logger.info("페이지에서 전달받은 데이터: {}", user);
	}
	
	@ResponseBody
	@RequestMapping(value = "/advanceSecond", method = RequestMethod.POST)
	public UserVO advanceSecond() {
		logger.info("advanceSecond 메서드 실행.");
		
		UserVO vo = new UserVO("asdf", "1234");
		logger.info("페이지로 전달할 데이터: {}", vo);
		
		return vo;
	}

}
